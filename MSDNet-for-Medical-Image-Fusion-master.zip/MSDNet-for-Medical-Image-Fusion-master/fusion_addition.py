# Additioin

def Strategy(content, style):
    # return tf.reduce_sum(content, style)
    return content+style

